import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { loadExamData } from '../data/examData';

interface Question {
  id: number;
  category: string;
  text: string;
  type: 'multiple-choice' | 'fill-in-blank';
  options?: { label: string; text: string }[];
}

interface Answer {
  questionId: number;
  correctAnswer: string;
  explanation: string;
}

interface ExamContextType {
  examState: 'setup' | 'active' | 'completed';
  setExamState: (state: 'setup' | 'active' | 'completed') => void;
  
  questions: Question[];
  answers: Answer[];
  isLoading: boolean;
  
  currentQuestionIndex: number;
  setCurrentQuestionIndex: (index: number) => void;
  
  userAnswers: Map<number, string>;
  setUserAnswer: (questionId: number, answer: string) => void;
  
  markedQuestions: Set<number>;
  toggleMarkedQuestion: (questionId: number) => void;
  isQuestionMarked: (questionId: number) => boolean;
  
  timeLimit: number;
  setTimeLimit: (minutes: number) => void;
  timeRemaining: number;
  
  goToNextQuestion: () => void;
  goToPreviousQuestion: () => void;
  goToQuestion: (index: number) => void;
  goToNextMarkedQuestion: () => void;
  
  startExam: () => void;
  completeExam: () => void;
  resetExam: () => void;
  
  calculateScore: () => { score: number; total: number; percentage: number };
  getCorrectAnswer: (questionId: number) => string | undefined;
  getExplanation: (questionId: number) => string | undefined;
}

const ExamContext = createContext<ExamContextType | undefined>(undefined);

export const ExamProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [examState, setExamState] = useState<'setup' | 'active' | 'completed'>('setup');
  
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  
  const [userAnswers, setUserAnswers] = useState<Map<number, string>>(new Map());
  const [markedQuestions, setMarkedQuestions] = useState<Set<number>>(new Set());
  
  const [timeLimit, setTimeLimit] = useState(120); // Default: 120 minutes
  const [timeRemaining, setTimeRemaining] = useState(timeLimit * 60); // in seconds
  const [timerActive, setTimerActive] = useState(false);
  
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true);
      try {
        const data = await loadExamData();
        setQuestions(data.questions);
        setAnswers(data.answers);
      } catch (error) {
        console.error('Error loading exam data:', error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  useEffect(() => {
    let interval: number | undefined;
    
    if (timerActive && timeRemaining > 0) {
      interval = window.setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            completeExam();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timerActive, timeRemaining]);
  
  const setUserAnswer = (questionId: number, answer: string) => {
    setUserAnswers(new Map(userAnswers.set(questionId, answer)));
  };
  
  const goToNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };
  
  const goToPreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };
  
  const goToQuestion = (index: number) => {
    if (index >= 0 && index < questions.length) {
      setCurrentQuestionIndex(index);
    }
  };
  
  const startExam = () => {
    setExamState('active');
    setTimeRemaining(timeLimit * 60);
    setTimerActive(true);
  };
  
  const completeExam = () => {
    setExamState('completed');
    setTimerActive(false);
  };
  
  const resetExam = () => {
    setExamState('setup');
    setCurrentQuestionIndex(0);
    setUserAnswers(new Map());
    setMarkedQuestions(new Set());
    setTimerActive(false);
    setTimeRemaining(timeLimit * 60);
  };
  
  const calculateScore = () => {
    let correctCount = 0;
    
    for (const [questionId, userAnswer] of userAnswers.entries()) {
      const correctAnswer = getCorrectAnswer(questionId);
      if (correctAnswer && userAnswer.toUpperCase() === correctAnswer.toUpperCase()) {
        correctCount++;
      }
    }
    
    return {
      score: correctCount,
      total: questions.length,
      percentage: (correctCount / questions.length) * 100
    };
  };
  
  const getCorrectAnswer = (questionId: number) => {
    const answer = answers.find(a => a.questionId === questionId);
    return answer?.correctAnswer;
  };
  
  const getExplanation = (questionId: number) => {
    const answer = answers.find(a => a.questionId === questionId);
    return answer?.explanation;
  };
  
  const toggleMarkedQuestion = (questionId: number) => {
    setMarkedQuestions(prevMarked => {
      const newMarked = new Set(prevMarked);
      if (newMarked.has(questionId)) {
        newMarked.delete(questionId);
      } else {
        newMarked.add(questionId);
      }
      return newMarked;
    });
  };
  
  const isQuestionMarked = (questionId: number) => {
    return markedQuestions.has(questionId);
  };
  
  const goToNextMarkedQuestion = () => {
    if (markedQuestions.size === 0) return;
    
    const currentQuestionId = questions[currentQuestionIndex]?.id;
    const questionIds = Array.from(questions.map(q => q.id));
    const markedIds = Array.from(markedQuestions).sort((a, b) => {
      return questionIds.indexOf(a) - questionIds.indexOf(b);
    });
    
    const currentIdIndex = markedIds.findIndex(id => id > currentQuestionId);
    if (currentIdIndex !== -1) {
      const nextMarkedId = markedIds[currentIdIndex];
      const nextIndex = questions.findIndex(q => q.id === nextMarkedId);
      if (nextIndex !== -1) {
        setCurrentQuestionIndex(nextIndex);
        return;
      }
    }
    
    const firstMarkedId = markedIds[0];
    const firstIndex = questions.findIndex(q => q.id === firstMarkedId);
    if (firstIndex !== -1) {
      setCurrentQuestionIndex(firstIndex);
    }
  };
  
  const value: ExamContextType = {
    examState,
    setExamState,
    questions,
    answers,
    isLoading,
    currentQuestionIndex,
    setCurrentQuestionIndex,
    userAnswers,
    setUserAnswer,
    markedQuestions,
    toggleMarkedQuestion,
    isQuestionMarked,
    timeLimit,
    setTimeLimit,
    timeRemaining,
    goToNextQuestion,
    goToPreviousQuestion,
    goToQuestion,
    goToNextMarkedQuestion,
    startExam,
    completeExam,
    resetExam,
    calculateScore,
    getCorrectAnswer,
    getExplanation
  };
  
  return <ExamContext.Provider value={value}>{children}</ExamContext.Provider>;
};

export const useExam = () => {
  const context = useContext(ExamContext);
  if (context === undefined) {
    throw new Error('useExam must be used within an ExamProvider');
  }
  return context;
};
