import React from 'react';
import { useExam } from '../contexts/ExamContext';
import Question from './Question';
import Navigation from './Navigation';
import Timer from './Timer';
import { Button } from './ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from './ui/alert-dialog';

const ExamContent: React.FC = () => {
  const { completeExam, userAnswers, questions } = useExam();
  
  const handleSubmit = () => {
    completeExam();
  };
  
  return (
    <div className="container mx-auto py-8 px-4">
      <Timer />
      
      <div className="flex flex-col md:flex-row gap-6">
        <div className="w-full md:w-3/4 space-y-6">
          <Question />
          
          <div className="flex justify-center">
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="default" className="w-full md:w-auto">
                  Submit Exam
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    You have answered {userAnswers.size} out of {questions.length} questions.
                    {userAnswers.size < questions.length && (
                      <span className="block mt-2 text-red-500">
                        Warning: You have {questions.length - userAnswers.size} unanswered questions.
                      </span>
                    )}
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleSubmit}>
                    Submit Exam
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
        
        <div className="w-full md:w-1/4">
          <Navigation />
        </div>
      </div>
    </div>
  );
};

export default ExamContent;
