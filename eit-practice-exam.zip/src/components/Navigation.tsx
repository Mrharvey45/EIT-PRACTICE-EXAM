import React from 'react';
import { useExam } from '../contexts/ExamContext';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Flag } from 'lucide-react';

const Navigation: React.FC = () => {
  const { questions, currentQuestionIndex, userAnswers, goToQuestion, markedQuestions, isQuestionMarked } = useExam();
  
  const categories = [...new Set(questions.map(q => q.category))];
  const questionsByCategory = categories.reduce((acc, category) => {
    acc[category] = questions.filter(q => q.category === category);
    return acc;
  }, {} as Record<string, typeof questions>);
  
  const getQuestionStatus = (questionId: number, index: number): string => {
    if (index === currentQuestionIndex) return 'current';
    if (isQuestionMarked(questionId)) return 'marked';
    return userAnswers.has(questionId) ? 'answered' : 'unanswered';
  };
  
  const getButtonVariant = (status: string): "default" | "outline" | "secondary" | "ghost" | "destructive" => {
    switch (status) {
      case 'current':
        return 'default';
      case 'answered':
        return 'secondary';
      case 'marked':
        return 'destructive';
      default:
        return 'outline';
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-lg">Question Navigator</CardTitle>
        <div className="flex flex-col gap-1">
          <div className="text-sm text-gray-500">
            {userAnswers.size} of {questions.length} questions answered
          </div>
          <div className="text-sm text-red-500 flex items-center gap-1">
            <Flag className="h-3 w-3" /> {markedQuestions.size} questions marked for review
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {categories.map((category) => (
            <div key={category} className="space-y-2">
              <h3 className="text-sm font-medium">{category}</h3>
              <div className="grid grid-cols-5 gap-2">
                {questionsByCategory[category].map((question) => {
                  const questionIndex = questions.findIndex(q => q.id === question.id);
                  const status = getQuestionStatus(question.id, questionIndex);
                  
                  return (
                    <Button
                      key={question.id}
                      variant={getButtonVariant(status)}
                      size="sm"
                      onClick={() => goToQuestion(questionIndex)}
                      className={`h-8 w-8 p-0 relative ${isQuestionMarked(question.id) ? 'border-red-500 border-2' : ''}`}
                    >
                      {question.id}
                      {isQuestionMarked(question.id) && (
                        <div className="absolute -top-1 -right-1">
                          <Flag className="h-3 w-3 text-red-500" />
                        </div>
                      )}
                    </Button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default Navigation;
