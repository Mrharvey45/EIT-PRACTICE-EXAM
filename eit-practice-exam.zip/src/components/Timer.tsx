import React, { useEffect, useState } from 'react';
import { useExam } from '../contexts/ExamContext';
import { AlertCircle, Clock } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from './ui/alert';

const Timer: React.FC = () => {
  const { timeRemaining, completeExam } = useExam();
  const [showWarning, setShowWarning] = useState(false);
  const [warningMessage, setWarningMessage] = useState('');
  
  const formatTime = (seconds: number): string => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };
  
  useEffect(() => {
    if (timeRemaining === 30 * 60) { // 30 minutes
      setWarningMessage('30 minutes remaining');
      setShowWarning(true);
    } else if (timeRemaining === 10 * 60) { // 10 minutes
      setWarningMessage('10 minutes remaining');
      setShowWarning(true);
    } else if (timeRemaining === 5 * 60) { // 5 minutes
      setWarningMessage('5 minutes remaining');
      setShowWarning(true);
    } else if (timeRemaining === 60) { // 1 minute
      setWarningMessage('1 minute remaining');
      setShowWarning(true);
    } else if (timeRemaining === 0) { // Time's up
      completeExam();
    } else {
      const timer = setTimeout(() => {
        setShowWarning(false);
      }, 5000);
      
      return () => clearTimeout(timer);
    }
  }, [timeRemaining, completeExam]);
  
  const getTimerColor = (): string => {
    if (timeRemaining <= 5 * 60) return 'text-red-500'; // Red for last 5 minutes
    if (timeRemaining <= 10 * 60) return 'text-orange-500'; // Orange for last 10 minutes
    return 'text-green-500'; // Green otherwise
  };
  
  return (
    <div className="fixed top-4 right-4 z-50">
      <div className={`flex items-center gap-2 text-lg font-bold ${getTimerColor()}`}>
        <Clock className="h-5 w-5" />
        <span>{formatTime(timeRemaining)}</span>
      </div>
      
      {showWarning && (
        <Alert className="mt-2 w-64 bg-yellow-50 border-yellow-200">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Time Warning</AlertTitle>
          <AlertDescription>{warningMessage}</AlertDescription>
        </Alert>
      )}
    </div>
  );
};

export default Timer;
