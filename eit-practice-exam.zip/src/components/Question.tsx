import React, { useState, useEffect } from 'react';
import { useExam } from '../contexts/ExamContext';
import { Button } from './ui/button';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from './ui/card';
import { ChevronLeft, ChevronRight, Flag, ArrowRight } from 'lucide-react';

const Question: React.FC = () => {
  const { 
    questions, 
    currentQuestionIndex, 
    userAnswers, 
    setUserAnswer, 
    goToNextQuestion, 
    goToPreviousQuestion,
    markedQuestions,
    toggleMarkedQuestion,
    isQuestionMarked,
    goToNextMarkedQuestion
  } = useExam();
  
  const [localAnswer, setLocalAnswer] = useState<string>('');
  
  const currentQuestion = questions[currentQuestionIndex];
  
  useEffect(() => {
    if (currentQuestion) {
      const savedAnswer = userAnswers.get(currentQuestion.id);
      setLocalAnswer(savedAnswer || '');
    }
  }, [currentQuestion, userAnswers]);
  
  if (!currentQuestion) {
    return <div>Loading question...</div>;
  }
  
  const handleOptionSelect = (value: string) => {
    setLocalAnswer(value);
    setUserAnswer(currentQuestion.id, value);
  };
  
  const handleTextInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setLocalAnswer(value);
    setUserAnswer(currentQuestion.id, value);
  };
  
  return (
    <Card className="w-full max-w-3xl mx-auto">
      <CardHeader>
        <div className="flex justify-between items-center">
          <div className="text-sm text-gray-500">
            Question {currentQuestionIndex + 1} of {questions.length}
          </div>
          <div className="text-sm font-medium text-blue-600">
            {currentQuestion.category}
          </div>
        </div>
        <CardTitle className="text-xl mt-2">
          {currentQuestion.text}
        </CardTitle>
      </CardHeader>
      
      <CardContent>
        {currentQuestion.type === 'multiple-choice' && currentQuestion.options ? (
          <RadioGroup 
            value={localAnswer} 
            onValueChange={handleOptionSelect}
            className="space-y-3"
          >
            {currentQuestion.options.map((option) => (
              <div key={option.label} className="flex items-start space-x-2">
                <RadioGroupItem 
                  value={option.label} 
                  id={`option-${option.label}`} 
                  className="mt-1"
                />
                <Label 
                  htmlFor={`option-${option.label}`}
                  className="cursor-pointer flex-1"
                >
                  <span className="font-medium">{option.label})</span> {option.text}
                </Label>
              </div>
            ))}
          </RadioGroup>
        ) : (
          <div className="space-y-2">
            <Label htmlFor="fill-answer">Your Answer:</Label>
            <Input
              id="fill-answer"
              value={localAnswer}
              onChange={handleTextInput}
              placeholder="Type your answer here"
              className="w-full"
            />
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between flex-wrap gap-2">
        <div className="flex gap-2">
          <Button
            variant="outline"
            onClick={goToPreviousQuestion}
            disabled={currentQuestionIndex === 0}
            className="flex items-center gap-1"
          >
            <ChevronLeft className="h-4 w-4" /> Previous
          </Button>
          
          <Button
            variant="outline"
            onClick={goToNextQuestion}
            disabled={currentQuestionIndex === questions.length - 1}
            className="flex items-center gap-1"
          >
            Next <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant={isQuestionMarked(currentQuestion.id) ? "secondary" : "outline"}
            onClick={() => toggleMarkedQuestion(currentQuestion.id)}
            className="flex items-center gap-1"
          >
            <Flag className="h-4 w-4" /> 
            {isQuestionMarked(currentQuestion.id) ? "Unmark" : "Mark"} Question
          </Button>
          
          <Button
            variant="outline"
            onClick={goToNextMarkedQuestion}
            disabled={markedQuestions.size === 0}
            className="flex items-center gap-1"
          >
            <ArrowRight className="h-4 w-4" /> Next Marked
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default Question;
