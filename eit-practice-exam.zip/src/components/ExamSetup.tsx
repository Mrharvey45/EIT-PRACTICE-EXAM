import React, { useState } from 'react';
import { useExam } from '../contexts/ExamContext';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';

const ExamSetup: React.FC = () => {
  const { startExam, timeLimit, setTimeLimit, questions, isLoading } = useExam();
  const [customTime, setCustomTime] = useState(timeLimit);

  const handleStartExam = () => {
    setTimeLimit(customTime);
    startExam();
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-50">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">EIT Practice Exam</CardTitle>
          <CardDescription className="text-center">
            Test your knowledge with 100 practice questions
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
              <p className="mt-4">Loading exam questions...</p>
            </div>
          ) : (
            <>
              <div className="mb-6">
                <h3 className="font-medium mb-2">Exam Information</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Total Questions: {questions.length}</li>
                  <li>Topics: Mathematics, Ethics, Engineering Economics, and more</li>
                  <li>Question Types: Multiple choice and fill-in-the-blank</li>
                  <li>Passing Score: 70% or higher</li>
                </ul>
              </div>
              
              <div className="mb-6">
                <h3 className="font-medium mb-2">Instructions</h3>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>You can navigate between questions using the navigation panel</li>
                  <li>The timer will count down from your selected time limit</li>
                  <li>You can submit the exam at any time</li>
                  <li>Unanswered questions will be marked as incorrect</li>
                </ul>
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="time-limit">Time Limit (minutes)</Label>
                <Input
                  id="time-limit"
                  type="number"
                  min="10"
                  max="240"
                  value={customTime}
                  onChange={(e) => setCustomTime(Number(e.target.value))}
                  className="w-full"
                />
                <p className="text-xs text-gray-500">
                  Default: 120 minutes (2 hours). You can adjust this between 10 and 240 minutes.
                </p>
              </div>
            </>
          )}
        </CardContent>
        <CardFooter>
          <Button 
            onClick={handleStartExam} 
            className="w-full" 
            disabled={isLoading}
          >
            Start Exam
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
};

export default ExamSetup;
