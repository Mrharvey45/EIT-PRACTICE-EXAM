import React, { useState } from 'react';
import { useExam } from '../contexts/ExamContext';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { CheckCircle, XCircle } from 'lucide-react';

const Results: React.FC = () => {
  const { 
    questions, 
    userAnswers, 
    calculateScore, 
    getCorrectAnswer, 
    getExplanation, 
    resetExam 
  } = useExam();
  
  const [selectedQuestionId, setSelectedQuestionId] = useState<number | null>(null);
  
  const { score, total, percentage } = calculateScore();
  const isPassing = percentage >= 70;
  
  const categories = [...new Set(questions.map(q => q.category))];
  const questionsByCategory = categories.reduce((acc, category) => {
    acc[category] = questions.filter(q => q.category === category);
    return acc;
  }, {} as Record<string, typeof questions>);
  
  const categoryScores = categories.map(category => {
    const categoryQuestions = questionsByCategory[category];
    let categoryCorrect = 0;
    
    categoryQuestions.forEach(question => {
      const userAnswer = userAnswers.get(question.id);
      const correctAnswer = getCorrectAnswer(question.id);
      
      if (userAnswer && correctAnswer && userAnswer.toUpperCase() === correctAnswer.toUpperCase()) {
        categoryCorrect++;
      }
    });
    
    return {
      category,
      correct: categoryCorrect,
      total: categoryQuestions.length,
      percentage: (categoryCorrect / categoryQuestions.length) * 100
    };
  });
  
  const isQuestionCorrect = (questionId: number): boolean => {
    const userAnswer = userAnswers.get(questionId);
    const correctAnswer = getCorrectAnswer(questionId);
    
    return !!(userAnswer && correctAnswer && userAnswer.toUpperCase() === correctAnswer.toUpperCase());
  };
  
  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <Card>
        <CardHeader className={isPassing ? "bg-green-50" : "bg-red-50"}>
          <CardTitle className="text-2xl text-center">Exam Results</CardTitle>
          <CardDescription className="text-center">
            You scored {score} out of {total} ({percentage.toFixed(1)}%)
          </CardDescription>
          <div className="text-center mt-2">
            <span 
              className={`inline-block px-3 py-1 rounded-full text-white ${
                isPassing ? 'bg-green-500' : 'bg-red-500'
              }`}
            >
              {isPassing ? 'PASS' : 'FAIL'}
            </span>
          </div>
        </CardHeader>
        
        <CardContent className="pt-6">
          <h3 className="font-medium mb-3">Performance by Category</h3>
          <div className="space-y-3">
            {categoryScores.map(({ category, correct, total, percentage }) => (
              <div key={category} className="flex items-center justify-between">
                <div className="font-medium">{category}</div>
                <div className="flex items-center gap-2">
                  <div className="text-sm">
                    {correct}/{total} ({percentage.toFixed(1)}%)
                  </div>
                  <div 
                    className={`w-16 h-2 rounded-full ${
                      percentage >= 70 ? 'bg-green-500' : 'bg-red-500'
                    }`}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
        
        <CardFooter>
          <Button onClick={resetExam} className="w-full">
            Retake Exam
          </Button>
        </CardFooter>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Detailed Review</CardTitle>
          <CardDescription>
            Review all questions and see explanations for the correct answers
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          <Tabs defaultValue={categories[0]}>
            <TabsList className="grid" style={{ gridTemplateColumns: `repeat(${categories.length}, 1fr)` }}>
              {categories.map(category => (
                <TabsTrigger key={category} value={category}>
                  {category.split(' ')[0]}
                </TabsTrigger>
              ))}
            </TabsList>
            
            {categories.map(category => (
              <TabsContent key={category} value={category} className="space-y-4 pt-4">
                {questionsByCategory[category].map(question => {
                  const isCorrect = isQuestionCorrect(question.id);
                  const userAnswer = userAnswers.get(question.id) || 'Not answered';
                  const correctAnswer = getCorrectAnswer(question.id) || '';
                  
                  return (
                    <div 
                      key={question.id}
                      className={`p-4 rounded-lg border ${
                        isCorrect ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'
                      }`}
                    >
                      <div className="flex items-start gap-2">
                        <div className="mt-1">
                          {isCorrect ? (
                            <CheckCircle className="h-5 w-5 text-green-500" />
                          ) : (
                            <XCircle className="h-5 w-5 text-red-500" />
                          )}
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex justify-between">
                            <div className="font-medium">Question {question.id}</div>
                            <Button 
                              variant="ghost" 
                              size="sm"
                              onClick={() => setSelectedQuestionId(
                                selectedQuestionId === question.id ? null : question.id
                              )}
                            >
                              {selectedQuestionId === question.id ? 'Hide' : 'Show'} Details
                            </Button>
                          </div>
                          
                          {selectedQuestionId === question.id && (
                            <div className="mt-2 space-y-2">
                              <p>{question.text}</p>
                              
                              {question.type === 'multiple-choice' && question.options && (
                                <div className="grid grid-cols-1 gap-1 mt-2">
                                  {question.options.map(option => (
                                    <div 
                                      key={option.label}
                                      className={`p-2 rounded ${
                                        option.label === correctAnswer
                                          ? 'bg-green-100 border border-green-200'
                                          : option.label === userAnswer && option.label !== correctAnswer
                                            ? 'bg-red-100 border border-red-200'
                                            : 'bg-gray-50 border border-gray-200'
                                      }`}
                                    >
                                      <span className="font-medium">{option.label})</span> {option.text}
                                    </div>
                                  ))}
                                </div>
                              )}
                              
                              <div className="mt-3 space-y-1">
                                <div className="text-sm">
                                  <span className="font-medium">Your answer:</span> {userAnswer}
                                </div>
                                <div className="text-sm">
                                  <span className="font-medium">Correct answer:</span> {correctAnswer}
                                </div>
                                <div className="text-sm mt-2">
                                  <span className="font-medium">Explanation:</span> {getExplanation(question.id)}
                                </div>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default Results;
