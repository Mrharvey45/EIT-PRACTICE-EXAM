import './App.css'
import { ExamProvider, useExam } from './contexts/ExamContext'
import ExamSetup from './components/ExamSetup'
import ExamContent from './components/ExamContent'
import Results from './components/Results'

const ExamStateContent = () => {
  const { examState } = useExam();
  
  switch (examState) {
    case 'setup':
      return <ExamSetup />;
    case 'active':
      return <ExamContent />;
    case 'completed':
      return <Results />;
    default:
      return <ExamSetup />;
  }
};

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <ExamProvider>
        <ExamStateContent />
      </ExamProvider>
    </div>
  )
}

export default App
