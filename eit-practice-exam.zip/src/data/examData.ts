interface Question {
  id: number;
  category: string;
  text: string;
  type: 'multiple-choice' | 'fill-in-blank';
  options?: { label: string; text: string }[];
}

interface Answer {
  questionId: number;
  correctAnswer: string;
  explanation: string;
}

export const questions: Question[] = [
  {
    id: 1,
    category: "Mathematics & Statistics",
    text: "The solution to the equation 2x²−5x+3=0 is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "x=1,x=1.5" },
      { label: "B", text: "x=−1,x=−1.5" },
      { label: "C", text: "x=3,x=−0.5" },
      { label: "D", text: "x=0.5,x=3" }
    ]
  },
  {
    id: 2,
    category: "Mathematics & Statistics",
    text: "What is the mean of the data set: {2, 5, 7, 10, 11}?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "7" },
      { label: "B", text: "8" },
      { label: "C", text: "6" },
      { label: "D", text: "7.5" }
    ]
  },
  {
    id: 3,
    category: "Mathematics & Statistics",
    text: "If a line passes through points (2,3) and (4,7), its slope is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "1" },
      { label: "B", text: "2" },
      { label: "C", text: "3" },
      { label: "D", text: "4" }
    ]
  },
  {
    id: 4,
    category: "Mathematics & Statistics",
    text: "What is the standard deviation of {4, 4, 4, 4, 4}?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "4" },
      { label: "B", text: "0" },
      { label: "C", text: "2" },
      { label: "D", text: "1" }
    ]
  },
  {
    id: 5,
    category: "Mathematics & Statistics",
    text: "The derivative of f(x)=5x³ at x=2 is:",
    type: "fill-in-blank"
  },
  {
    id: 6,
    category: "Mathematics & Statistics",
    text: "Evaluate the definite integral: ∫₀²(3x²) dx",
    type: "multiple-choice",
    options: [
      { label: "A", text: "4" },
      { label: "B", text: "6" },
      { label: "C", text: "8" },
      { label: "D", text: "12" }
    ]
  },
  {
    id: 7,
    category: "Mathematics & Statistics",
    text: "What is the probability of rolling a sum of 7 with two fair dice?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "1/6" },
      { label: "B", text: "1/12" },
      { label: "C", text: "1/8" },
      { label: "D", text: "1/36" }
    ]
  },
  {
    id: 8,
    category: "Ethics & Professional Practice",
    text: "Which of the following is considered unethical for a professional engineer?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Reporting unsafe conditions" },
      { label: "B", text: "Signing off on plans prepared by others without review" },
      { label: "C", text: "Continuing education" },
      { label: "D", text: "Disclosing a conflict of interest" }
    ]
  },
  {
    id: 9,
    category: "Ethics & Professional Practice",
    text: "The main duty of an engineer to the public is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "To increase company profit" },
      { label: "B", text: "To protect public health, safety, and welfare" },
      { label: "C", text: "To follow company policy" },
      { label: "D", text: "To maintain secrecy" }
    ]
  },
  {
    id: 10,
    category: "Engineering Economics",
    text: "If $5,000 is invested at 8% annual interest, compounded annually, what is the value after 3 years?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "$5,400" },
      { label: "B", text: "$5,832" },
      { label: "C", text: "$6,299" },
      { label: "D", text: "$6,480" }
    ]
  },
  {
    id: 11,
    category: "Engineering Economics",
    text: "A project has a first cost of $10,000 and generates $2,500 per year for 5 years. The payback period is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "2 years" },
      { label: "B", text: "3 years" },
      { label: "C", text: "4 years" },
      { label: "D", text: "5 years" }
    ]
  },
  {
    id: 12,
    category: "Statics",
    text: "A simply supported beam AB is 6 m long with a point load of 12 kN at midspan. What is the reaction at support A?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "3 kN" },
      { label: "B", text: "6 kN" },
      { label: "C", text: "12 kN" },
      { label: "D", text: "18 kN" }
    ]
  },
  {
    id: 13,
    category: "Statics",
    text: "What is the moment about point A caused by a 100 N force acting perpendicular at 0.5 m from A?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "25 Nm" },
      { label: "B", text: "50 Nm" },
      { label: "C", text: "100 Nm" },
      { label: "D", text: "200 Nm" }
    ]
  },
  {
    id: 14,
    category: "Statics",
    text: "Which of the following is NOT a two-force member?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Tie rod" },
      { label: "B", text: "Pin" },
      { label: "C", text: "Cable" },
      { label: "D", text: "Truss member" }
    ]
  },
  {
    id: 15,
    category: "Dynamics",
    text: "An object is dropped from rest. How far does it fall in 2 seconds? (g = 9.81 m/s²)",
    type: "multiple-choice",
    options: [
      { label: "A", text: "9.81 m" },
      { label: "B", text: "19.62 m" },
      { label: "C", text: "4.91 m" },
      { label: "D", text: "39.24 m" }
    ]
  },
  {
    id: 16,
    category: "Mechanics of Materials",
    text: "A steel rod of 2 m length and cross-sectional area 200 mm² is loaded axially with 20 kN. What is the stress?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "50 MPa" },
      { label: "B", text: "100 MPa" },
      { label: "C", text: "150 MPa" },
      { label: "D", text: "200 MPa" }
    ]
  },
  {
    id: 17,
    category: "Mechanics of Materials",
    text: "The modulus of elasticity for most steels is approximately:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "20 GPa" },
      { label: "B", text: "200 GPa" },
      { label: "C", text: "2,000 GPa" },
      { label: "D", text: "20,000 GPa" }
    ]
  },
  {
    id: 18,
    category: "Materials",
    text: "The main ingredient in Portland cement is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Silica" },
      { label: "B", text: "Alumina" },
      { label: "C", text: "Lime" },
      { label: "D", text: "Iron oxide" }
    ]
  },
  {
    id: 19,
    category: "Fluid Mechanics",
    text: "Water flows at 2 m/s in a 0.5 m diameter pipe. The volumetric flow rate is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "0.25 m³/s" },
      { label: "B", text: "0.39 m³/s" },
      { label: "C", text: "0.40 m³/s" },
      { label: "D", text: "1.57 m³/s" }
    ]
  },
  {
    id: 20,
    category: "Surveying",
    text: "The sum of interior angles of a pentagon is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "360°" },
      { label: "B", text: "450°" },
      { label: "C", text: "540°" },
      { label: "D", text: "720°" }
    ]
  },
  {
    id: 21,
    category: "Surveying",
    text: "A benchmark in surveying is used to:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Mark property boundaries" },
      { label: "B", text: "Establish a reference point of known elevation" },
      { label: "C", text: "Measure horizontal angles" },
      { label: "D", text: "Calculate areas" }
    ]
  },
  {
    id: 22,
    category: "Water Resources & Environmental",
    text: "Which of the following is NOT a primary water treatment process?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Sedimentation" },
      { label: "B", text: "Filtration" },
      { label: "C", text: "Biological treatment" },
      { label: "D", text: "Coagulation" }
    ]
  },
  {
    id: 23,
    category: "Water Resources & Environmental",
    text: "The best soil for a septic drain field is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Sand" },
      { label: "B", text: "Clay" },
      { label: "C", text: "Silt" },
      { label: "D", text: "Loam" }
    ]
  },
  {
    id: 24,
    category: "Structural Engineering",
    text: "For a simply supported beam with a uniformly distributed load, the maximum moment occurs:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "At midspan" },
      { label: "B", text: "At support" },
      { label: "C", text: "At quarter point" },
      { label: "D", text: "At any point" }
    ]
  },
  {
    id: 25,
    category: "Geotechnical Engineering",
    text: "The Atterberg limits are used to describe:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Soil compaction" },
      { label: "B", text: "Soil consistency" },
      { label: "C", text: "Soil density" },
      { label: "D", text: "Soil strength" }
    ]
  },
  {
    id: 26,
    category: "Mathematics & Statistics",
    text: "The area under the curve y=x² from x=0 to x=3 is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "6" },
      { label: "B", text: "9" },
      { label: "C", text: "12" },
      { label: "D", text: "18" }
    ]
  },
  {
    id: 27,
    category: "Mathematics & Statistics",
    text: "If the probability of rain tomorrow is 0.4, what is the probability that it will NOT rain?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "0.2" },
      { label: "B", text: "0.4" },
      { label: "C", text: "0.6" },
      { label: "D", text: "0.8" }
    ]
  },
  {
    id: 28,
    category: "Mathematics & Statistics",
    text: "For the data set {4, 8, 12, 16}, the median is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "8" },
      { label: "B", text: "10" },
      { label: "C", text: "12" },
      { label: "D", text: "16" }
    ]
  },
  {
    id: 29,
    category: "Mathematics & Statistics",
    text: "The value of log₁₀(1000) is:",
    type: "fill-in-blank"
  },
  {
    id: 30,
    category: "Mathematics & Statistics",
    text: "Which of the following is a solution to x²−16=0?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "2" },
      { label: "B", text: "-4" },
      { label: "C", text: "8" },
      { label: "D", text: "4" }
    ]
  },
  {
    id: 31,
    category: "Ethics & Professional Practice",
    text: "If you discover a design error that may cause a safety issue, you should:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Ignore it" },
      { label: "B", text: "Report it to your supervisor immediately" },
      { label: "C", text: "Wait until construction is complete" },
      { label: "D", text: "Tell your coworkers only" }
    ]
  },
  {
    id: 32,
    category: "Ethics & Professional Practice",
    text: "Which of the following best defines \"conflict of interest\"?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Competing priorities within a project" },
      { label: "B", text: "Favoring personal gain over professional duty" },
      { label: "C", text: "Working on multiple projects" },
      { label: "D", text: "Disagreement among team members" }
    ]
  },
  {
    id: 33,
    category: "Engineering Economics",
    text: "What is the present worth of $1,000 received in 5 years at a 6% interest rate (annual compounding)?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "$747" },
      { label: "B", text: "$705" },
      { label: "C", text: "$800" },
      { label: "D", text: "$950" }
    ]
  },
  {
    id: 34,
    category: "Engineering Economics",
    text: "The annual cost for a machine with a first cost of $8,000, a life of 10 years, and no salvage value at 10% interest is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "$800" },
      { label: "B", text: "$1,303" },
      { label: "C", text: "$1,250" },
      { label: "D", text: "$2,000" }
    ]
  },
  {
    id: 35,
    category: "Statics",
    text: "A force of 500 N is applied at a 30° angle above the horizontal. The vertical component is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "125 N" },
      { label: "B", text: "250 N" },
      { label: "C", text: "433 N" },
      { label: "D", text: "500 N" }
    ]
  },
  {
    id: 36,
    category: "Statics",
    text: "A truss with a pin at A and a roller at B supports a load at the top joint C. What is the support reaction at B if the total load is 10 kN?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "2.5 kN" },
      { label: "B", text: "5 kN" },
      { label: "C", text: "7.5 kN" },
      { label: "D", text: "10 kN" }
    ]
  },
  {
    id: 37,
    category: "Statics",
    text: "Which statement about equilibrium is correct?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "The sum of moments about any point is zero" },
      { label: "B", text: "The sum of forces in the x direction is zero" },
      { label: "C", text: "The sum of forces in the y direction is zero" },
      { label: "D", text: "All of the above" }
    ]
  },
  {
    id: 38,
    category: "Dynamics",
    text: "A car accelerates uniformly from 10 m/s to 30 m/s in 4 seconds. The acceleration is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "2.5 m/s²" },
      { label: "B", text: "5 m/s²" },
      { label: "C", text: "10 m/s²" },
      { label: "D", text: "20 m/s²" }
    ]
  },
  {
    id: 39,
    category: "Dynamics",
    text: "On a velocity-time graph, the area under the curve represents:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "The total distance traveled" },
      { label: "B", text: "The acceleration" },
      { label: "C", text: "The force" },
      { label: "D", text: "The momentum" }
    ]
  },
  {
    id: 40,
    category: "Mechanics of Materials",
    text: "The strain in a 3 m rod that stretches 0.015 m is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "0.0005" },
      { label: "B", text: "0.005" },
      { label: "C", text: "0.05" },
      { label: "D", text: "0.15" }
    ]
  },
  {
    id: 41,
    category: "Mechanics of Materials",
    text: "The moment of inertia (I) for a rectangle about its base (width b, height h) is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "⅓bh³" },
      { label: "B", text: "⅟₁₂bh³" },
      { label: "C", text: "½bh³" },
      { label: "D", text: "bh²" }
    ]
  },
  {
    id: 42,
    category: "Materials",
    text: "Which test measures the hardness of steel?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Charpy impact test" },
      { label: "B", text: "Brinell test" },
      { label: "C", text: "Compression test" },
      { label: "D", text: "Shear test" }
    ]
  },
  {
    id: 43,
    category: "Materials",
    text: "Which concrete type is best for high early strength?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Type I" },
      { label: "B", text: "Type II" },
      { label: "C", text: "Type III" },
      { label: "D", text: "Type IV" }
    ]
  },
  {
    id: 44,
    category: "Fluid Mechanics",
    text: "Reynolds number is used to determine:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Viscosity" },
      { label: "B", text: "Turbulence" },
      { label: "C", text: "Density" },
      { label: "D", text: "Velocity" }
    ]
  },
  {
    id: 45,
    category: "Fluid Mechanics",
    text: "The pressure at 10 m below the surface of water (density 1000 kg/m³, g = 9.81 m/s²) is:",
    type: "fill-in-blank"
  },
  {
    id: 46,
    category: "Surveying",
    text: "The U.S. Public Land Survey System divides land into:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Quadrangles" },
      { label: "B", text: "Townships" },
      { label: "C", text: "Sectors" },
      { label: "D", text: "Plats" }
    ]
  },
  {
    id: 47,
    category: "Surveying",
    text: "The instrument used to measure horizontal and vertical angles in surveying is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Dumpy level" },
      { label: "B", text: "Theodolite" },
      { label: "C", text: "Chain" },
      { label: "D", text: "Altimeter" }
    ]
  },
  {
    id: 48,
    category: "Water Resources & Environmental",
    text: "Eutrophication in lakes is caused by:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Increased oxygen" },
      { label: "B", text: "Increased nutrients" },
      { label: "C", text: "Decreased temperature" },
      { label: "D", text: "Decreased pH" }
    ]
  },
  {
    id: 49,
    category: "Water Resources & Environmental",
    text: "The main purpose of a detention pond is to:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Provide drinking water" },
      { label: "B", text: "Recharge groundwater" },
      { label: "C", text: "Control stormwater runoff" },
      { label: "D", text: "Treat sewage" }
    ]
  },
  {
    id: 50,
    category: "Structural Engineering",
    text: "For a cantilever beam loaded at the free end, maximum deflection occurs:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "At the fixed support" },
      { label: "B", text: "At the free end" },
      { label: "C", text: "At midspan" },
      { label: "D", text: "Uniformly along the length" }
    ]
  },
  {
    id: 51,
    category: "Mathematics & Statistics",
    text: "What is the Laplace transform of f(t)=e³ᵗ?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "1/(s+3)" },
      { label: "B", text: "1/(s-3)" },
      { label: "C", text: "1/s" },
      { label: "D", text: "3/s" }
    ]
  },
  {
    id: 52,
    category: "Mathematics & Statistics",
    text: "The derivative of y=sin(2x) with respect to x is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "cos(2x)" },
      { label: "B", text: "2cos(2x)" },
      { label: "C", text: "-2sin(2x)" },
      { label: "D", text: "2sin(2x)" }
    ]
  },
  {
    id: 53,
    category: "Mathematics & Statistics",
    text: "The determinant of the matrix [2 3; 4 5] is:",
    type: "fill-in-blank"
  },
  {
    id: 54,
    category: "Mathematics & Statistics",
    text: "Which of the following is a solution to x²+9=0?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "3" },
      { label: "B", text: "-3" },
      { label: "C", text: "0" },
      { label: "D", text: "3i" }
    ]
  },
  {
    id: 55,
    category: "Mathematics & Statistics",
    text: "A sample contains {1, 2, 4, 8}. The geometric mean is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "3" },
      { label: "B", text: "2.83" },
      { label: "C", text: "3.76" },
      { label: "D", text: "4" }
    ]
  },
  {
    id: 56,
    category: "Ethics & Professional Practice",
    text: "If you are offered a gift from a contractor bidding on your project, you should:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Accept it" },
      { label: "B", text: "Politely decline" },
      { label: "C", text: "Negotiate a better gift" },
      { label: "D", text: "Ignore the situation" }
    ]
  },
  {
    id: 57,
    category: "Ethics & Professional Practice",
    text: "The NSPE Code of Ethics states that engineers shall:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Act as faithful agents for their employers" },
      { label: "B", text: "Prioritize profit" },
      { label: "C", text: "Conceal errors" },
      { label: "D", text: "Overrule safety concerns" }
    ]
  },
  {
    id: 58,
    category: "Engineering Economics",
    text: "Which is an example of a sunk cost?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Money spent on equipment last year" },
      { label: "B", text: "Maintenance cost next year" },
      { label: "C", text: "Salvage value at end of project" },
      { label: "D", text: "Present value of future receipts" }
    ]
  },
  {
    id: 59,
    category: "Engineering Economics",
    text: "The uniform series present worth factor is used to:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Find future value of a lump sum" },
      { label: "B", text: "Discount a series of equal payments" },
      { label: "C", text: "Calculate depreciation" },
      { label: "D", text: "Determine IRR" }
    ]
  },
  {
    id: 60,
    category: "Statics",
    text: "If a force is applied at an angle θ to the horizontal, the horizontal component is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Fsinθ" },
      { label: "B", text: "Fcosθ" },
      { label: "C", text: "Ftanθ" },
      { label: "D", text: "F/sinθ" }
    ]
  },
  {
    id: 61,
    category: "Statics",
    text: "A simply supported beam (length 8 m) has a uniformly distributed load of 3 kN/m. What is the total reaction at each support?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "12 kN" },
      { label: "B", text: "24 kN" },
      { label: "C", text: "6 kN" },
      { label: "D", text: "18 kN" }
    ]
  },
  {
    id: 62,
    category: "Statics",
    text: "Which support allows horizontal movement?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Fixed" },
      { label: "B", text: "Roller" },
      { label: "C", text: "Pin" },
      { label: "D", text: "None of the above" }
    ]
  },
  {
    id: 63,
    category: "Dynamics",
    text: "A 2-kg mass moves at 10 m/s. What is its kinetic energy?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "10 J" },
      { label: "B", text: "20 J" },
      { label: "C", text: "100 J" },
      { label: "D", text: "200 J" }
    ]
  },
  {
    id: 64,
    category: "Dynamics",
    text: "A projectile reaches maximum height in 3 s. What is the initial vertical velocity? (Use g = 9.81 m/s²)",
    type: "multiple-choice",
    options: [
      { label: "A", text: "9.81 m/s" },
      { label: "B", text: "19.6 m/s" },
      { label: "C", text: "29.4 m/s" },
      { label: "D", text: "39.2 m/s" }
    ]
  },
  {
    id: 65,
    category: "Mechanics of Materials",
    text: "The factor of safety is the ratio of:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Ultimate strength to yield strength" },
      { label: "B", text: "Yield strength to ultimate strength" },
      { label: "C", text: "Ultimate strength to allowable strength" },
      { label: "D", text: "Allowable strength to ultimate strength" }
    ]
  },
  {
    id: 66,
    category: "Mechanics of Materials",
    text: "The shear stress at the neutral axis of a rectangular beam in bending is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Maximum" },
      { label: "B", text: "Minimum" },
      { label: "C", text: "Zero" },
      { label: "D", text: "Varies linearly" }
    ]
  },
  {
    id: 67,
    category: "Materials",
    text: "Which of these is an aggregate property most important for concrete durability?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Color" },
      { label: "B", text: "Absorption" },
      { label: "C", text: "Shape" },
      { label: "D", text: "Gradation" }
    ]
  },
  {
    id: 68,
    category: "Materials",
    text: "The main cause of corrosion in steel reinforcement is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Carbonation" },
      { label: "B", text: "Chloride ions" },
      { label: "C", text: "Oxidation" },
      { label: "D", text: "Hydrogenation" }
    ]
  },
  {
    id: 69,
    category: "Fluid Mechanics",
    text: "Bernoulli's equation applies to:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Viscous, compressible flow" },
      { label: "B", text: "Inviscid, incompressible flow" },
      { label: "C", text: "Turbulent, compressible flow" },
      { label: "D", text: "Laminar, compressible flow" }
    ]
  },
  {
    id: 70,
    category: "Fluid Mechanics",
    text: "The manometer reads 0.3 m of mercury. What is the equivalent pressure in kPa? (Density of Hg = 13,600 kg/m³; g = 9.81 m/s²)",
    type: "multiple-choice",
    options: [
      { label: "A", text: "4.01" },
      { label: "B", text: "13.01" },
      { label: "C", text: "29.94" },
      { label: "D", text: "40.07" }
    ]
  },
  {
    id: 71,
    category: "Surveying",
    text: "In differential leveling, the difference in elevation between two points is calculated as:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Foresight – Backsight" },
      { label: "B", text: "Backsight – Foresight" },
      { label: "C", text: "Height of instrument – Foresight" },
      { label: "D", text: "Foresight – Height of instrument" }
    ]
  },
  {
    id: 72,
    category: "Surveying",
    text: "The purpose of a benchmark in surveying is to:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Mark property corners" },
      { label: "B", text: "Provide a reference point of known elevation" },
      { label: "C", text: "Measure horizontal angles" },
      { label: "D", text: "Establish property lines" }
    ]
  },
  {
    id: 73,
    category: "Water Resources & Environmental",
    text: "BOD in wastewater treatment stands for:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Biological Oxygen Demand" },
      { label: "B", text: "Biochemical Oxygen Demand" },
      { label: "C", text: "Basic Oxygen Demand" },
      { label: "D", text: "Bacterial Oxygen Depletion" }
    ]
  },
  {
    id: 74,
    category: "Water Resources & Environmental",
    text: "The primary purpose of a clarifier in water treatment is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Disinfection" },
      { label: "B", text: "Sedimentation" },
      { label: "C", text: "Aeration" },
      { label: "D", text: "Filtration" }
    ]
  },
  {
    id: 75,
    category: "Structural Engineering",
    text: "The slenderness ratio of a column is defined as:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Length/Width" },
      { label: "B", text: "Effective length/Radius of gyration" },
      { label: "C", text: "Cross-sectional area/Length" },
      { label: "D", text: "Moment of inertia/Length" }
    ]
  },
  {
    id: 76,
    category: "Structural Engineering",
    text: "In reinforced concrete design, stirrups primarily resist:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Compression" },
      { label: "B", text: "Tension" },
      { label: "C", text: "Shear" },
      { label: "D", text: "Torsion" }
    ]
  },
  {
    id: 77,
    category: "Geotechnical Engineering",
    text: "The liquid limit of a soil is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "The water content at which soil begins to behave as a liquid" },
      { label: "B", text: "The minimum water content at which a soil can be rolled into threads" },
      { label: "C", text: "The water content at which soil has zero strength" },
      { label: "D", text: "The water content at which soil is fully saturated" }
    ]
  },
  {
    id: 78,
    category: "Geotechnical Engineering",
    text: "Which soil type typically has the highest permeability?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Clay" },
      { label: "B", text: "Silt" },
      { label: "C", text: "Sand" },
      { label: "D", text: "Organic soil" }
    ]
  },
  {
    id: 79,
    category: "Transportation Engineering",
    text: "The minimum stopping sight distance depends on:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Vehicle speed only" },
      { label: "B", text: "Reaction time only" },
      { label: "C", text: "Coefficient of friction only" },
      { label: "D", text: "All of the above" }
    ]
  },
  {
    id: 80,
    category: "Transportation Engineering",
    text: "The primary purpose of a superelevation in highway curves is to:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Increase visibility" },
      { label: "B", text: "Counteract centrifugal force" },
      { label: "C", text: "Improve drainage" },
      { label: "D", text: "Reduce noise" }
    ]
  },
  {
    id: 81,
    category: "Mathematics & Statistics",
    text: "The solution to the differential equation dy/dx = 2x with y(0)=1 is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "y = x² + 1" },
      { label: "B", text: "y = 2x + 1" },
      { label: "C", text: "y = x² - 1" },
      { label: "D", text: "y = 2x - 1" }
    ]
  },
  {
    id: 82,
    category: "Mathematics & Statistics",
    text: "The expected value of a fair six-sided die is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "3" },
      { label: "B", text: "3.5" },
      { label: "C", text: "6" },
      { label: "D", text: "21" }
    ]
  },
  {
    id: 83,
    category: "Ethics & Professional Practice",
    text: "An engineer discovers that a client is violating environmental regulations. The engineer should:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Ignore it as it's not their responsibility" },
      { label: "B", text: "Inform the client and suggest corrective action" },
      { label: "C", text: "Immediately report to authorities without informing the client" },
      { label: "D", text: "Resign from the project without explanation" }
    ]
  },
  {
    id: 84,
    category: "Engineering Economics",
    text: "The break-even point occurs when:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Revenue equals fixed costs" },
      { label: "B", text: "Revenue equals variable costs" },
      { label: "C", text: "Revenue equals total costs" },
      { label: "D", text: "Profit equals total costs" }
    ]
  },
  {
    id: 85,
    category: "Engineering Economics",
    text: "The net present value (NPV) of a project is positive. This means:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "The project should be rejected" },
      { label: "B", text: "The project is economically viable" },
      { label: "C", text: "The payback period is too long" },
      { label: "D", text: "The internal rate of return is negative" }
    ]
  },
  {
    id: 86,
    category: "Statics",
    text: "A 5 kN force and an 8 kN force act at right angles to each other. The magnitude of the resultant force is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "3 kN" },
      { label: "B", text: "9.4 kN" },
      { label: "C", text: "13 kN" },
      { label: "D", text: "40 kN" }
    ]
  },
  {
    id: 87,
    category: "Dynamics",
    text: "A 1000 kg car accelerates from 0 to 20 m/s in 10 seconds. The power required at the end of this period is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "2 kW" },
      { label: "B", text: "20 kW" },
      { label: "C", text: "40 kW" },
      { label: "D", text: "200 kW" }
    ]
  },
  {
    id: 88,
    category: "Mechanics of Materials",
    text: "Poisson's ratio for most metals is approximately:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "0.1" },
      { label: "B", text: "0.3" },
      { label: "C", text: "0.5" },
      { label: "D", text: "0.7" }
    ]
  },
  {
    id: 89,
    category: "Materials",
    text: "Which of the following is NOT a ferrous metal?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Cast iron" },
      { label: "B", text: "Stainless steel" },
      { label: "C", text: "Aluminum" },
      { label: "D", text: "Carbon steel" }
    ]
  },
  {
    id: 90,
    category: "Fluid Mechanics",
    text: "The hydraulic diameter of a rectangular duct with width w and height h is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "2(w+h)" },
      { label: "B", text: "√(w²+h²)" },
      { label: "C", text: "4wh/(2w+2h)" },
      { label: "D", text: "wh/(w+h)" }
    ]
  },
  {
    id: 91,
    category: "Thermodynamics",
    text: "The first law of thermodynamics is a statement of conservation of:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Mass" },
      { label: "B", text: "Energy" },
      { label: "C", text: "Momentum" },
      { label: "D", text: "Entropy" }
    ]
  },
  {
    id: 92,
    category: "Thermodynamics",
    text: "The efficiency of a Carnot engine operating between 400K and 300K is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "0.25" },
      { label: "B", text: "0.33" },
      { label: "C", text: "0.75" },
      { label: "D", text: "1.33" }
    ]
  },
  {
    id: 93,
    category: "Electrical Engineering",
    text: "Ohm's Law states that:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "V = IR" },
      { label: "B", text: "P = IV" },
      { label: "C", text: "I = P/V" },
      { label: "D", text: "R = P/I²" }
    ]
  },
  {
    id: 94,
    category: "Electrical Engineering",
    text: "A 100W light bulb operating at 120V draws a current of:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "0.83 A" },
      { label: "B", text: "1.2 A" },
      { label: "C", text: "8.3 A" },
      { label: "D", text: "12 A" }
    ]
  },
  {
    id: 95,
    category: "Computer Engineering",
    text: "Which logic gate performs the operation: Output = 1 if and only if all inputs are 1?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "OR" },
      { label: "B", text: "AND" },
      { label: "C", text: "NOT" },
      { label: "D", text: "XOR" }
    ]
  },
  {
    id: 96,
    category: "Computer Engineering",
    text: "The binary representation of the decimal number 25 is:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "11001" },
      { label: "B", text: "10101" },
      { label: "C", text: "10011" },
      { label: "D", text: "11101" }
    ]
  },
  {
    id: 97,
    category: "Construction Management",
    text: "The critical path in a project schedule represents:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "The shortest possible completion time" },
      { label: "B", text: "The most expensive sequence of activities" },
      { label: "C", text: "The sequence with zero float" },
      { label: "D", text: "The sequence with maximum resources" }
    ]
  },
  {
    id: 98,
    category: "Construction Management",
    text: "Which of the following is NOT typically included in project overhead costs?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Site office" },
      { label: "B", text: "Material costs" },
      { label: "C", text: "Project manager salary" },
      { label: "D", text: "Temporary utilities" }
    ]
  },
  {
    id: 99,
    category: "Engineering Law",
    text: "A professional engineer's seal on documents indicates:",
    type: "multiple-choice",
    options: [
      { label: "A", text: "The document is perfect" },
      { label: "B", text: "The engineer takes responsibility for the work" },
      { label: "C", text: "The document is copyrighted" },
      { label: "D", text: "The document has been approved by authorities" }
    ]
  },
  {
    id: 100,
    category: "Engineering Law",
    text: "Which of the following best describes 'negligence' in engineering practice?",
    type: "multiple-choice",
    options: [
      { label: "A", text: "Failure to meet contractual obligations" },
      { label: "B", text: "Failure to exercise reasonable care" },
      { label: "C", text: "Intentional violation of codes" },
      { label: "D", text: "Unauthorized practice" }
    ]
  }
];

export const answers: Answer[] = [
  {
    questionId: 1,
    correctAnswer: "A",
    explanation: "Factor or use quadratic formula. 2x²−5x+3=0 gives x=1 and x=1.5."
  },
  {
    questionId: 2,
    correctAnswer: "A",
    explanation: "(2+5+7+10+11)/5 = 35/5 = 7."
  },
  {
    questionId: 3,
    correctAnswer: "B",
    explanation: "Slope = (7-3)/(4-2) = 4/2 = 2."
  },
  {
    questionId: 4,
    correctAnswer: "B",
    explanation: "All numbers are the same, so no deviation from the mean."
  },
  {
    questionId: 5,
    correctAnswer: "60",
    explanation: "Derivative is 15x²; at x=2, 15×2²=60."
  },
  {
    questionId: 6,
    correctAnswer: "C",
    explanation: "∫₀²3x²dx=[x³]₀²×3=(8-0)×1=8."
  },
  {
    questionId: 7,
    correctAnswer: "A",
    explanation: "There are 6 ways to make 7 out of 36 total combinations."
  },
  {
    questionId: 8,
    correctAnswer: "B",
    explanation: "Must review before signing; this is unethical."
  },
  {
    questionId: 9,
    correctAnswer: "B",
    explanation: "This is the primary ethical responsibility."
  },
  {
    questionId: 10,
    correctAnswer: "C",
    explanation: "5000×1.08³=5000×1.2597=6,299."
  },
  {
    questionId: 11,
    correctAnswer: "D",
    explanation: "Payback = 10,000 / 2,500 = 4 years (to recoup), but 5 years to receive all payments."
  },
  {
    questionId: 12,
    correctAnswer: "B",
    explanation: "For simply supported beam with midspan load, each reaction = load/2 = 12/2 = 6 kN."
  },
  {
    questionId: 13,
    correctAnswer: "B",
    explanation: "Moment = Force x Distance = 100 N x 0.5 m = 50 Nm."
  },
  {
    questionId: 14,
    correctAnswer: "B",
    explanation: "Pins are connections, not two-force members. Others are two-force members (force acts at ends)."
  },
  {
    questionId: 15,
    correctAnswer: "B",
    explanation: "s=½gt²=0.5×9.81×4=19.62 m."
  },
  {
    questionId: 16,
    correctAnswer: "B",
    explanation: "Stress = F/A=20,000/200=100 MPa."
  },
  {
    questionId: 17,
    correctAnswer: "B",
    explanation: "Approximate modulus of elasticity for steel is 200 GPa."
  },
  {
    questionId: 18,
    correctAnswer: "C",
    explanation: "Portland cement is mostly calcium oxide (lime)."
  },
  {
    questionId: 19,
    correctAnswer: "B",
    explanation: "Q=vA=2×π/4×(0.5)²=2×0.196=0.392≈0.39 m³/s."
  },
  {
    questionId: 20,
    correctAnswer: "C",
    explanation: "Interior angles of n-gon: (n-2)×180 = (5-2)×180 = 540°."
  },
  {
    questionId: 21,
    correctAnswer: "B",
    explanation: "A benchmark is a reference point of known elevation used as a starting point for surveying."
  },
  {
    questionId: 22,
    correctAnswer: "C",
    explanation: "Biological treatment is a secondary treatment process, not primary."
  },
  {
    questionId: 23,
    correctAnswer: "A",
    explanation: "Sand provides good drainage and aerobic conditions for septic systems."
  },
  {
    questionId: 24,
    correctAnswer: "A",
    explanation: "For a simply supported beam with UDL, maximum moment occurs at midspan."
  },
  {
    questionId: 25,
    correctAnswer: "B",
    explanation: "Atterberg limits (liquid limit, plastic limit) describe soil consistency at different moisture contents."
  },
  {
    questionId: 26,
    correctAnswer: "B",
    explanation: "∫₀³x²dx = [x³/3]₀³ = 9/3 = 9."
  },
  {
    questionId: 27,
    correctAnswer: "C",
    explanation: "P(not rain) = 1 - P(rain) = 1 - 0.4 = 0.6."
  },
  {
    questionId: 28,
    correctAnswer: "B",
    explanation: "For {4, 8, 12, 16}, median = (8+12)/2 = 10."
  },
  {
    questionId: 29,
    correctAnswer: "3",
    explanation: "log₁₀(1000) = log₁₀(10³) = 3."
  },
  {
    questionId: 30,
    correctAnswer: "D",
    explanation: "x²−16=0 gives x²=16, so x=±4. Option D is 4."
  },
  {
    questionId: 31,
    correctAnswer: "B",
    explanation: "Safety issues must be reported immediately to protect public welfare."
  },
  {
    questionId: 32,
    correctAnswer: "B",
    explanation: "Conflict of interest occurs when personal interests compromise professional judgment."
  },
  {
    questionId: 33,
    correctAnswer: "A",
    explanation: "PW = 1000/(1.06)⁵ = 1000/1.3382 = $747."
  },
  {
    questionId: 34,
    correctAnswer: "B",
    explanation: "Annual cost = $8,000 × (A/P, 10%, 10) = $8,000 × 0.1627 = $1,303."
  },
  {
    questionId: 35,
    correctAnswer: "B",
    explanation: "Vertical component = 500 × sin(30°) = 500 × 0.5 = 250 N."
  },
  {
    questionId: 36,
    correctAnswer: "B",
    explanation: "For a symmetric truss with a vertical load, each support takes half: 10/2 = 5 kN."
  },
  {
    questionId: 37,
    correctAnswer: "D",
    explanation: "All three conditions must be satisfied for equilibrium."
  },
  {
    questionId: 38,
    correctAnswer: "B",
    explanation: "a = (v₂-v₁)/t = (30-10)/4 = 5 m/s²."
  },
  {
    questionId: 39,
    correctAnswer: "A",
    explanation: "Area under velocity-time curve represents distance traveled."
  },
  {
    questionId: 40,
    correctAnswer: "B",
    explanation: "Strain = change in length/original length = 0.015/3 = 0.005."
  },
  {
    questionId: 41,
    correctAnswer: "A",
    explanation: "Moment of inertia about base = ⅓bh³."
  },
  {
    questionId: 42,
    correctAnswer: "B",
    explanation: "Brinell test measures hardness by pressing a steel ball into the material."
  },
  {
    questionId: 43,
    correctAnswer: "C",
    explanation: "Type III cement is specifically designed for high early strength applications."
  },
  {
    questionId: 44,
    correctAnswer: "B",
    explanation: "Reynolds number is the ratio that determines whether flow is laminar or turbulent."
  },
  {
    questionId: 45,
    correctAnswer: "98.1",
    explanation: "P = ρgh = 1000 × 9.81 × 10 = 98,100 Pa = 98.1 kPa."
  },
  {
    questionId: 46,
    correctAnswer: "B",
    explanation: "The PLSS divides land into townships, which are 6 miles by 6 miles."
  },
  {
    questionId: 47,
    correctAnswer: "B",
    explanation: "A theodolite measures both horizontal and vertical angles in surveying."
  },
  {
    questionId: 48,
    correctAnswer: "B",
    explanation: "Excess nutrients cause algal blooms, leading to eutrophication."
  },
  {
    questionId: 49,
    correctAnswer: "C",
    explanation: "Detention ponds temporarily store stormwater to reduce peak flows."
  },
  {
    questionId: 50,
    correctAnswer: "B",
    explanation: "Maximum deflection in a cantilever beam with end load occurs at the free end."
  },
  {
    questionId: 51,
    correctAnswer: "B",
    explanation: "Laplace transform of e^(at) is 1/(s-a), so for e^(3t) it's 1/(s-3)."
  },
  {
    questionId: 52,
    correctAnswer: "B",
    explanation: "Using chain rule: d/dx[sin(2x)] = cos(2x) × d/dx[2x] = 2cos(2x)."
  },
  {
    questionId: 53,
    correctAnswer: "2",
    explanation: "Det[2 3; 4 5] = 2×5 - 3×4 = 10 - 12 = -2. The absolute value is 2."
  },
  {
    questionId: 54,
    correctAnswer: "D",
    explanation: "x²+9=0 gives x²=-9, so x=±3i. Option D is 3i."
  },
  {
    questionId: 55,
    correctAnswer: "B",
    explanation: "Geometric mean = (1×2×4×8)^(1/4) = 64^(1/4) = 2.83."
  },
  {
    questionId: 56,
    correctAnswer: "B",
    explanation: "Accepting gifts from contractors creates a conflict of interest and should be declined."
  },
  {
    questionId: 57,
    correctAnswer: "A",
    explanation: "Engineers must act as faithful agents for their employers while protecting public safety."
  },
  {
    questionId: 58,
    correctAnswer: "A",
    explanation: "Sunk costs are past expenditures that cannot be recovered."
  },
  {
    questionId: 59,
    correctAnswer: "B",
    explanation: "The uniform series present worth factor converts a series of equal payments to present value."
  },
  {
    questionId: 60,
    correctAnswer: "B",
    explanation: "Horizontal component = F × cos(θ)."
  },
  {
    questionId: 61,
    correctAnswer: "A",
    explanation: "Total load = 3 kN/m × 8 m = 24 kN. Each support takes half: 24/2 = 12 kN."
  },
  {
    questionId: 62,
    correctAnswer: "B",
    explanation: "A roller support allows horizontal movement while restraining vertical movement."
  },
  {
    questionId: 63,
    correctAnswer: "C",
    explanation: "KE = ½mv² = 0.5 × 2 × 10² = 100 J."
  },
  {
    questionId: 64,
    correctAnswer: "C",
    explanation: "At max height, v = 0. Using v = v₀ - gt, 0 = v₀ - 9.81 × 3, so v₀ = 29.43 m/s."
  },
  {
    questionId: 65,
    correctAnswer: "C",
    explanation: "Factor of safety = Ultimate strength / Allowable strength."
  },
  {
    questionId: 66,
    correctAnswer: "A",
    explanation: "Shear stress is maximum at the neutral axis in a rectangular beam."
  },
  {
    questionId: 67,
    correctAnswer: "B",
    explanation: "Absorption affects freeze-thaw durability and chemical resistance of concrete."
  },
  {
    questionId: 68,
    correctAnswer: "B",
    explanation: "Chloride ions are the primary cause of reinforcement corrosion in concrete."
  },
  {
    questionId: 69,
    correctAnswer: "B",
    explanation: "Bernoulli's equation applies to inviscid, incompressible flow."
  },
  {
    questionId: 70,
    correctAnswer: "D",
    explanation: "P = ρgh = 13600 × 9.81 × 0.3 = 40,070 Pa = 40.07 kPa."
  },
  {
    questionId: 71,
    correctAnswer: "B",
    explanation: "Difference in elevation = Backsight - Foresight."
  },
  {
    questionId: 72,
    correctAnswer: "B",
    explanation: "Benchmarks provide reference points of known elevation for surveying."
  },
  {
    questionId: 73,
    correctAnswer: "B",
    explanation: "BOD stands for Biochemical Oxygen Demand in wastewater treatment."
  },
  {
    questionId: 74,
    correctAnswer: "B",
    explanation: "Clarifiers are used for sedimentation to remove suspended solids."
  },
  {
    questionId: 75,
    correctAnswer: "B",
    explanation: "Slenderness ratio = Effective length / Radius of gyration."
  },
  {
    questionId: 76,
    correctAnswer: "C",
    explanation: "Stirrups in reinforced concrete primarily resist shear forces."
  },
  {
    questionId: 77,
    correctAnswer: "A",
    explanation: "The liquid limit is the water content at which soil begins to behave as a liquid."
  },
  {
    questionId: 78,
    correctAnswer: "C",
    explanation: "Sand has the highest permeability among the options due to larger pore spaces."
  },
  {
    questionId: 79,
    correctAnswer: "D",
    explanation: "Stopping sight distance depends on speed, reaction time, and friction coefficient."
  },
  {
    questionId: 80,
    correctAnswer: "B",
    explanation: "Superelevation counteracts centrifugal force on curves to prevent vehicles from sliding outward."
  },
  {
    questionId: 81,
    correctAnswer: "A",
    explanation: "Integrating dy/dx = 2x gives y = x² + C. With y(0) = 1, we get C = 1, so y = x² + 1."
  },
  {
    questionId: 82,
    correctAnswer: "B",
    explanation: "Expected value = (1+2+3+4+5+6)/6 = 21/6 = 3.5."
  },
  {
    questionId: 83,
    correctAnswer: "B",
    explanation: "Engineers should first inform clients of violations and suggest corrective action before escalating."
  },
  {
    questionId: 84,
    correctAnswer: "C",
    explanation: "Break-even occurs when revenue equals total costs (fixed + variable)."
  },
  {
    questionId: 85,
    correctAnswer: "B",
    explanation: "Positive NPV indicates the project is economically viable and should be accepted."
  },
  {
    questionId: 86,
    correctAnswer: "B",
    explanation: "Using Pythagorean theorem: √(5² + 8²) = √(25 + 64) = √89 ≈ 9.4 kN."
  },
  {
    questionId: 87,
    correctAnswer: "C",
    explanation: "Power = Force × Velocity = ma × v = 1000 × 2 × 20 = 40,000 W = 40 kW."
  },
  {
    questionId: 88,
    correctAnswer: "B",
    explanation: "Poisson's ratio for most metals is approximately 0.3."
  },
  {
    questionId: 89,
    correctAnswer: "C",
    explanation: "Aluminum is a non-ferrous metal. The others all contain iron."
  },
  {
    questionId: 90,
    correctAnswer: "C",
    explanation: "Hydraulic diameter = 4 × Area / Perimeter = 4wh/(2w+2h) = 4wh/(2(w+h))."
  },
  {
    questionId: 91,
    correctAnswer: "B",
    explanation: "The first law of thermodynamics is a statement of conservation of energy."
  },
  {
    questionId: 92,
    correctAnswer: "A",
    explanation: "Carnot efficiency = 1 - Tc/Th = 1 - 300/400 = 1 - 0.75 = 0.25 or 25%."
  },
  {
    questionId: 93,
    correctAnswer: "A",
    explanation: "Ohm's Law states that voltage equals current times resistance (V = IR)."
  },
  {
    questionId: 94,
    correctAnswer: "A",
    explanation: "I = P/V = 100/120 = 0.833 A."
  },
  {
    questionId: 95,
    correctAnswer: "B",
    explanation: "The AND gate outputs 1 only when all inputs are 1."
  },
  {
    questionId: 96,
    correctAnswer: "A",
    explanation: "25 in binary is 11001 (16+8+0+0+1)."
  },
  {
    questionId: 97,
    correctAnswer: "C",
    explanation: "The critical path is the sequence of activities with zero float that determines project duration."
  },
  {
    questionId: 98,
    correctAnswer: "B",
    explanation: "Material costs are direct costs, not overhead costs."
  },
  {
    questionId: 99,
    correctAnswer: "B",
    explanation: "A professional engineer's seal indicates they take responsibility for the work."
  },
  {
    questionId: 100,
    correctAnswer: "B",
    explanation: "Negligence in engineering is the failure to exercise reasonable care that a prudent engineer would exercise."
  }
];

export const loadExamData = async () => {
  console.log("Loading embedded exam data...");
  return { questions, answers };
};
