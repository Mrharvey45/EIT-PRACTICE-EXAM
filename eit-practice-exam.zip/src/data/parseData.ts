interface Question {
  id: number;
  category: string;
  text: string;
  type: 'multiple-choice' | 'fill-in-blank';
  options?: { label: string; text: string }[];
}

interface Answer {
  questionId: number;
  correctAnswer: string;
  explanation: string;
}

export const parseQuestions = async (): Promise<Question[]> => {
  try {
    const response = await fetch('/data/EIT+QUESTION+1-100.txt');
    const text = await response.text();
    const lines = text.split('\n');
    
    const questions: Question[] = [];
    let currentCategory = '';
    let currentQuestion: Partial<Question> = {};
    let currentOptions: { label: string; text: string }[] = [];
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (!line) continue;
      
      if (!line.match(/^\d+\./) && !line.match(/^[A-D]\)/)) {
        if (!line.match(/^\(/) && !line.includes('|')) {
          currentCategory = line;
          continue;
        }
      }
      
      const questionMatch = line.match(/^(\d+)\./);
      if (questionMatch) {
        if (currentQuestion.id) {
          questions.push(currentQuestion as Question);
          currentOptions = [];
        }
        
        const questionId = parseInt(questionMatch[1]);
        const questionText = line.substring(questionMatch[0].length).trim();
        
        currentQuestion = {
          id: questionId,
          category: currentCategory,
          text: questionText,
          type: 'multiple-choice', // Default, will update for fill-in-blank
        };
        
        if (i + 1 < lines.length && i + 2 < lines.length) {
          if (lines[i + 1].trim() === '' && lines[i + 2].trim().includes('Fill-in-the-Blank')) {
            currentQuestion.type = 'fill-in-blank';
            currentQuestion.text += ' ' + lines[i + 2].trim();
            i += 2; // Skip the next two lines
          }
        }
        
        continue;
      }
      
      const optionMatch = line.match(/^([A-D])\)/);
      if (optionMatch) {
        const optionLabel = optionMatch[1];
        const optionText = line.substring(optionMatch[0].length).trim();
        
        currentOptions.push({ label: optionLabel, text: optionText });
        
        if (currentOptions.length === 4 || (i + 1 < lines.length && lines[i + 1].trim().match(/^\d+\./))) {
          currentQuestion.options = [...currentOptions];
        }
        
        continue;
      }
      
      if (currentQuestion.id && !line.match(/^[A-D]\)/)) {
        currentQuestion.text += ' ' + line;
      }
    }
    
    if (currentQuestion.id) {
      questions.push(currentQuestion as Question);
    }
    
    return questions;
  } catch (error) {
    console.error('Error parsing questions:', error);
    return [];
  }
};

export const parseAnswers = async (): Promise<Answer[]> => {
  try {
    const response = await fetch('/data/EIT+answer+key.txt');
    const text = await response.text();
    const lines = text.split('\n');
    
    const answers: Answer[] = [];
    let currentAnswer: Partial<Answer> = {};
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (!line) continue;
      
      const answerMatch = line.match(/^(\d+)\.\s+([A-D])\)/);
      if (answerMatch) {
        if (currentAnswer.questionId) {
          answers.push(currentAnswer as Answer);
        }
        
        const questionId = parseInt(answerMatch[1]);
        const correctAnswer = answerMatch[2];
        
        currentAnswer = {
          questionId,
          correctAnswer,
          explanation: ''
        };
        
        continue;
      }
      
      if (line.startsWith('Explanation:')) {
        if (currentAnswer.questionId) {
          currentAnswer.explanation = line.substring('Explanation:'.length).trim();
        }
        continue;
      }
      
      const fillInMatch = line.match(/^(\d+)\.\s+(.+)$/);
      if (fillInMatch && !answerMatch) {
        if (currentAnswer.questionId) {
          answers.push(currentAnswer as Answer);
        }
        
        const questionId = parseInt(fillInMatch[1]);
        const correctAnswer = fillInMatch[2];
        
        currentAnswer = {
          questionId,
          correctAnswer,
          explanation: ''
        };
        
        continue;
      }
      
      if (currentAnswer.questionId && currentAnswer.explanation) {
        currentAnswer.explanation += ' ' + line;
      }
    }
    
    if (currentAnswer.questionId) {
      answers.push(currentAnswer as Answer);
    }
    
    return answers;
  } catch (error) {
    console.error('Error parsing answers:', error);
    return [];
  }
};

export const loadExamData = async () => {
  const questions = await parseQuestions();
  const answers = await parseAnswers();
  return { questions, answers };
};
